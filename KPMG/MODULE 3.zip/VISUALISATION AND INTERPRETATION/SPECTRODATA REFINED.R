# load data:
library(readxl)
library(plyr)
library(dplyr)
library(tibble)
library(magrittr)
library(tidyr)
library(ggmap)
library(RgoogleMaps)
spectro <- read_excel("~/KIPIMG.xlsx")

# Clean data

# 1. Gender
# Unique values in Gender:
unique(spectro$gender)
# "F"      "M"      "Female" "Male"   "U"      "Femal" 
# U means unknown gender

spectro$gender <- as.character(spectro$gender)

# Change "Female" and "Femal" to F
Female <- c("Female", "Femal")
spectro$gender <- revalue(spectro$gender, c(Female = "F"))

# Change "Male" to M
spectro$gender <- revalue(spectro$gender, c(Male = "M"))

# ________________________________________________________
# 2. Age $ Age group
spectro$DOB <- as.Date(spectro$DOB)
meDates <- spectro[, c("customer_id", "DOB")]
# Years determines as of today's date
Date <- "2020-09-05"
meDates$Years <- ceiling(as.numeric(lubridate::time_length(difftime(Date, meDates$DOB), "years")))

# Age groups
meDates <- meDates %>% mutate(agegroup = case_when(Years <= 20 ~ '1',
                                             Years >= 21  & Years <= 30 ~ '2',
                                             Years >= 31  & Years <= 40 ~ '3',
                                             Years >= 41  & Years <= 50 ~ '4',
                                             Years >= 51  & Years <= 60 ~ '5',
                                             Years >= 61 ~ '6'))
spectro <- add_column(spectro, meDates[,c("Years", "agegroup")], .after = 4)
# __________________________________________________________

# 3. Locations
#    a. States
unique(spectro$state)
# "New South Wales", "QLD", "VIC", "NSW",  "Victoria"
spectro$state <- revalue(spectro$state, c("New South Wales" = "NSW"))
spectro$state <- revalue(spectro$state, c("Victoria" = "VIC"))


#    b. New_Address
spectro$New_Address = paste(spectro$address,",",spectro$state,",","Australia")
# ____________________________________________________________

col <- c("job_title", "wealth_segment", "owns_car", "gender", "agegroup", "job_industry_category", "state")
spectro %<>%
  mutate_each_(funs(factor(.)),col)

# check structure for spectro data
str(spectro)

# Check how many missing values we have in Jobtitle:
# View(spectro[is.na(spectro$job_title),])

# 610 entries
# Fill the job entries with the title above it..
spectro = spectro %>%
  fill(job_title, .direction = "up")

# Return all entries having Job_Entries as "n/a"
# View(spectro[spectro$job_industry_category == "n/a",])
# 820 entries
# fill the entry with "General"

spectro$job_industry_category <- revalue(spectro$job_industry_category, c("n/a" = "General"))

View(spectro)
# Previous transactions: customer_id 1-4000
# New customer data: customer_id 4001- 5000

# As noted earlier clients with unknown DOB have missing Age and agegroups.
# 142 entries in total.
# Drop them and any entry with missing data
dim(spectro)
spectro <- spectro %>% drop_na(DOB)

# Location longitude and latitude:

register_google(key = "AIzaSyDLgK2Ld_sClr5PZgBxJYhlfq_4nXCaVzc")

for(i in 1:nrow(spectro)){
  loc_coord <- data.frame(tryCatch(geocode(spectro$New_Address[i], output = "latlona",
                                           source = "google"), warning = function(w) data.frame(lon = NA, lat = NA, address = NA)))
  spectro$lat[i] <- as.numeric(loc_coord[2])
  spectro$lon[i] <- as.numeric(loc_coord[1])
}

spectro <- spectro[, c(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,17,18,16)]
# Save data for Visualization and interpretation.
write.csv(spectro, "REFINED_SPECTRODATA FOR VISUALISATION.csv")

# The dependent variable:
Trans <- read_excel("C:/Users/Musebe/Desktop/Transactions.xlsx")
Trans$customer_id <- as.factor(Trans$customer_id)
No_of_Sales_by_ID <- as.data.frame(table(Trans$customer_id))

write.csv(No_of_Sales_by_ID, "Sales.csv")